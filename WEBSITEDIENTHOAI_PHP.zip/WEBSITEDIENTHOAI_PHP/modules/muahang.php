<div class="panel panel-info">
      <div class="panel-heading"><img src="image/muiten3.png"> CHÍNH SÁCH MUA HÀNG</div>
          <div class="panel-body">
          		<h2><p align="center"><font color="#9A750E">CHÀO MỪNG BẠN GHÉ THĂM WEBSITE VNBLACKBERRY</font></p></h2>
          <p><b><font color="#FF4700">THỜI GIAN LÀM VIỆC CỦA CỬA HÀNG:</font></b></br></br>
          Mở cửa từ 09h00 - Đóng cửa vào lúc 19h00 từ thứ 2 đến thứ 7.</br></br>
          Chủ nhật : Mở cửa từ 09h00 đóng cửa vào lúc 12h00.</br></br>
          Lịch làm việc ngày lễ - ngày nghỉ sẽ cập nhật sau.</br></br>
          <b><font color="#FF4700">I. MUA HÀNG VÀ CÁC DỊCH VỤ TẠI VNBLACKBERRY</font></b></br></br>
           <i><font color="#FF4700">1. KHÁCH HÀNG TẠI BẮC NINH</font></i></br></br>
           Cửa hàng vnBlackBerry: T36 - Thị Trấn Hồ - Thuận Thành - Bắc Ninh</br></br>
           Liên hệ: <font color="blue">01663636890</font></br></br>
           Hoặc: <font color="blue">01657381202</font></br></br>
           Quý khách được hướng dẫn tư vấn trọn đời máy tại cửa hàng</br></br>
           <i><font color="#FF4700">2. ĐỐI VỚI KHÁCH HÀNG MUA HÀNG TỪ XA</font></i></br></br>
           Khách hàng liên hệ với cửa hàng  theo số điện thoại dưới đây để đặt hàng.</br></br>
           SĐT: <font color="blue">01663636890</font> (anh Tuấn Anh)</br></br>
           Chuyển khoản vào tài khoản vnBlackBerry theo những tài khoản dưới đây:</br></br>
           *Vietcombank  : <font color="blue">0011002811285</font> ( Chi nhánh Bắc Ninh )</br></br>
           *Techcombank  : <font color="blue">19025378154018</font> ( Chi nhánh Bắc Ninh )</br></br>
           Chủ tài khoản : <font color="blue">Huỳnh Cao Nguyên</font></br></br>
           * Agribank    : <font color="blue">1506205152938</font> ( Chi nhánh Bắc Ninh )</br></br>
           *Đông á bank  : <font color="blue">0101016504</font> ( Chi nhánh Bắc Ninh )</br></br>
           * BIDV        : <font color="blue">21210000089128</font> ( Chi nhánh Bắc Ninh )</br></br>
           Chủ tài khoản: <font color="blue">Lê Sỹ Tuấn Anh</font></br></br>
           Sau khi chuyển khoản khách hàng liên hệ lại. vnBlackBerry sẽ liên hệ để lấy địa chỉ giao hàng.</br></br>
           Hàng sẽ được gửi trong ngày sau khi khách hàng chuyển khoản</br></br>
           <b><font color="#FF4700">II. CHÍNH SÁCH GIAO HÀNG</font></b></br></br>
           Miễn phí ship hàng toàn quốc đối với những đơn hàng giá trị trên 1,500,000 VND</br></br>
           Đối với những đơn hàng có giá trị dưới 1,500,000 VND phí ship hàng là 50,000 VND</br></br>
           Đối với các mặt hàng khuyến mại không áp dụng miễn phí ship hàng</br></br>
           Phí ship hàng đối với phụ kiện 30,000 VND</br></br>
           <b><font color="#FF4700">III. CHÍNH SÁCH KHÁCH HÀNG</font></b></br></br>
           vnBlackBerry luôn cố gắng làm hài lòng khách hàng với phương châm giá cả hợp lý, sản phẩm chất lượng đến tay người tiêu dùng.</br></br>
           vnBlackBerry luôn có chương trình khuyến mại dành cho khách hàng đã từng mua hàng.</br></br>
           Tặng thẻ giảm giá 200k cho mọi khách hàng mua sản phẩm trên 4tr.</br></br>
           Tặng thẻ giảm giá 100k cho mọi khách hàng mua sản phẩm trên 1,5tr.</br></br>
           Ap dụng với mọi khách hàng mua Blackberry. Riêng các dòng sản phẩm khác sẽ có cập nhật riêng.</br></br>
           Luôn luôn trân trọng và biết ơn sự ủng hộ của quý khách hàng. Nhằm phục vụ tốt hơn. Kính mong sự đóng góp ý kiến của khách hàng về phong cách bán hàng và chất lượng sản phẩm nhằm hoàn thiện hơn nữa.</br></br>
           Mọi ý kiến đóng góp của khách hàng xin gửi về:</br></br>
           vnBlackBerry@gmail.com --- <font color="blue">Hotline: 01663636890</font></br></br>
           <b><font color="#FF4700">IV. DỊCH VỤ SAU BÁN HÀNG</font></b></br></br>
           vnBlackBerry hỗ trợ tư vấn sử dụng các sản phẩm, hỗ trợ  phần mềm trọn đời các dòng máy do vnBlackBerry bán ra.</br></br>
           Các dịch vụ cài đặt được miễn phí hoàn toàn, hỗ trợ quý khách hàng mua phần mềm bản quyền với giá ưu đãi nhất có thể.</br></br>
           <font color="blue">Liên hệ hỗ trợ kĩ thuật: 01657381202</font> (anh Nguyên)</br></br>
           Email: baohanh.vnBlackBerry@gmail.com</br></br>
           <b><font color="#FF4700">V. NHỮNG LƯU Ý KHI NHẬN HÀNG</font></b></br></br>
           Sau khi nhận tiền chuyển khoản của khách hàng. vnBlackBerry sẽ có trách nhiệm kiểm tra sản phẩm và giao cho bên dịch vụ chuyển phát nhanh.</br></br>
           Thời gian nhận hàng tùy thuộc địa điểm của quý khách hàng. Khi nhận hàng quý khách lưu ý nhìn kĩ niêm phong xem còn nguyên vẹn hay không. Nếu có vấn đề hãy liên hệ ngay số điện thoại dưới đây để được giải quyết kịp thời.</br></br>
           <font color="blue">vnBlackberry: 01663636890 ---  Email: vnBlackBerry@gmail.com</font>		
          </div>
</div>
