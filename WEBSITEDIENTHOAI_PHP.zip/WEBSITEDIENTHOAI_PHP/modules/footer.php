<div class="xoa"></div>
  <div id="footer">
    <ul>
	  <li><a href="#">Trang chủ</a></li>
	  <li><a href="#">Tin tức</a></li>
	  <li><a href="#">Bảo hành</a></li>					
	  <li><a href="#">Download</a></li>
      <li><a href="#">Liên hệ</a></li>
    </ul>
    <div class="copyright">Copyright: <a href="#">VNBlackBerry</a></div>
  </div>
