<?php 
	$ac=$_GET['ac'];
	if($ac=="lietke"){
	include("modules/nhanxet/lietke.php");
	}
?>