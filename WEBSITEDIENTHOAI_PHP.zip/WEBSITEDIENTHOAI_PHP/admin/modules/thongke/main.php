<?php 
	$ac=$_GET['ac'];
	include("modules/thongke/lietke.php");
?>