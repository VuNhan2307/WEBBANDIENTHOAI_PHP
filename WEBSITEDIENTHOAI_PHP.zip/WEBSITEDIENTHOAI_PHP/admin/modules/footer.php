<div class="xoa"></div>
<div id="footer">
	
</div>