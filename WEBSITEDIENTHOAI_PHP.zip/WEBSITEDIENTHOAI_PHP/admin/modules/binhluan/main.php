<?php 
	$ac=$_GET['ac'];
	if($ac=="lietke"){
		include("modules/binhluan/lietke.php");
	} 
?>