<div class="container-fluid">
  <div class="row">
  		<?php 
		include("menu.php");
		include("content.php");
		?>
  </div>
</div>