// JavaScript Document
	function xoa(){ 
		if( window.confirm("Bạn có chắc chắn xóa bỏ không?")){ 
		return true; 
		}else{ 
		return false 
		} 
		} 

